# VertiGoBoostReborn-15-15-Works-updated
the panel costs money and they are free why ? they are broken as well, so i decided to spend some time and fix one panel for you guys and it works 15:15 on draw with amazing results best map office reconnect delay 1 and loading delay 12
this is updates yes show some respect
